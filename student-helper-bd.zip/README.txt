STUDENT HELPER BD — QUICK START

1. index.html, style.css, script.js, robots.txt, sitemap.xml একই folder-এ রাখবে।
2. প্রথমে index.html ফোন/কম্পিউটারে খুলে test করো।
3. Website live করার সময় YOUR-DOMAIN.com দুই জায়গায় তোমার আসল domain দিয়ে replace করবে।
4. তারপর hosting-এ files upload করবে।
5. Google Search Console-এ domain/property verify করে sitemap.xml submit করবে।

IMPORTANT:
- এই starter site-এ placeholder resources আছে। Publish করার আগে নিজের useful notes/content যোগ করো।
- অন্যের বই/নোট হুবহু কপি করে upload কোরো না।
- GPA calculator এখানে simple average; বোর্ডের official GPA rules অনুযায়ী subject/4th subject হিসাব পরে আলাদা করে উন্নত করা উচিত।
