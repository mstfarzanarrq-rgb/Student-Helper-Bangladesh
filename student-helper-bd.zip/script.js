function calcGPA(){
 const vals=["gpa1","gpa2","gpa3"].map(id=>parseFloat(document.getElementById(id).value)).filter(v=>!isNaN(v));
 const el=document.getElementById("gpaResult");
 if(!vals.length){el.textContent="কমপক্ষে একটি GPA দাও।";return;}
 const avg=vals.reduce((a,b)=>a+b,0)/vals.length;
 el.textContent="Average GPA: "+avg.toFixed(2);
}
function calcPercentage(){
 const a=parseFloat(document.getElementById("obtained").value), t=parseFloat(document.getElementById("total").value);
 const el=document.getElementById("percentResult");
 if(isNaN(a)||isNaN(t)||t<=0){el.textContent="সঠিক নম্বর দাও।";return;}
 el.textContent="Percentage: "+((a/t)*100).toFixed(2)+"%";
}
function countdown(){
 const d=document.getElementById("examDate").value, el=document.getElementById("countResult");
 if(!d){el.textContent="একটি exam date দাও।";return;}
 const target=new Date(d+"T00:00:00"), now=new Date();
 const days=Math.ceil((target-now)/(1000*60*60*24));
 el.textContent=days>0?days+" দিন বাকি।":days===0?"আজ exam!":"তারিখটি চলে গেছে।";
}